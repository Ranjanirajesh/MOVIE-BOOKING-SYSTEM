export interface Movie {
  id: string;
  name: string;
  language: string;
  showTime: string;
  availableSeats: number;
  image: string;
  description: string;
  seats: boolean[];
}

export interface Booking {
  id: string;
  userId: string;
  movieId: string;
  movieName: string;
  userName: string;
  seats: number[];
  showTime: string;
  timestamp: Date;
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'user';
}
