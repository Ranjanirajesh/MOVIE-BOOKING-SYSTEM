import { useState, useEffect } from 'react';
import { Movie } from '../types';
import { Star, Ticket, Search, Filter } from 'lucide-react';
import { motion } from 'motion/react';
import { useNavigate } from 'react-router-dom';

export default function MovieList() {
  const [movies, setMovies] = useState<Movie[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    fetch('/api/movies')
      .then(res => res.json())
      .then(data => {
        setMovies(data);
        setLoading(false);
      });
  }, []);

  const filteredMovies = movies.filter(m => 
    m.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    m.language.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) return <div className="flex justify-center py-20"><div className="animate-spin h-8 w-8 border-2 border-indigo-500 border-t-transparent rounded-full" /></div>;

  return (
    <div className="space-y-8 py-8">
      <div className="flex flex-col md:flex-row justify-between items-center gap-6">
        <div>
          <h1 className="text-4xl font-black text-white">Now Showing</h1>
          <p className="text-slate-500 mt-2">Book your favorite movies instantly.</p>
        </div>
        <div className="relative w-full md:w-96">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
          <input 
            type="text" 
            placeholder="Search movies or languages..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-900 border border-slate-800 rounded-2xl pl-12 pr-4 py-3 text-white focus:ring-2 focus:ring-indigo-500/50 outline-none transition-all"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
        {filteredMovies.map(movie => (
          <motion.div
            key={movie.id}
            whileHover={{ y: -8 }}
            className="group bg-slate-900 rounded-3xl overflow-hidden border border-slate-800 hover:border-indigo-500/50 transition-all shadow-xl"
          >
            <div className="aspect-[2/3] relative overflow-hidden">
              <img 
                src={movie.image} 
                alt={movie.name} 
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                referrerPolicy="no-referrer"
              />
              <div className="absolute top-4 right-4 bg-black/60 backdrop-blur-md px-3 py-1 rounded-full text-xs font-bold text-indigo-400">
                {movie.language}
              </div>
            </div>
            <div className="p-6 space-y-4">
              <div>
                <h3 className="text-xl font-bold text-white truncate">{movie.name}</h3>
                <p className="text-slate-500 text-sm mt-1">{movie.showTime}</p>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-slate-400">Seats Available</span>
                <span className={`font-bold ${movie.availableSeats > 0 ? 'text-green-400' : 'text-red-400'}`}>
                  {movie.availableSeats}
                </span>
              </div>
              <button 
                onClick={() => navigate(`/book/${movie.id}`)}
                disabled={movie.availableSeats === 0}
                className="w-full bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-800 disabled:text-slate-600 text-white font-bold py-3 rounded-xl transition-colors flex items-center justify-center gap-2"
              >
                {movie.availableSeats > 0 ? 'Book Tickets' : 'Sold Out'}
                <Ticket className="w-4 h-4" />
              </button>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
