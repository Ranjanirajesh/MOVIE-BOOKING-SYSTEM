import { useState, useEffect } from 'react';
import { Movie, Booking } from '../types';
import { Plus, Trash2, Edit2, Film, Users, Ticket, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function AdminDashboard() {
  const [movies, setMovies] = useState<Movie[]>([]);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingMovie, setEditingMovie] = useState<Partial<Movie> | null>(null);

  useEffect(() => {
    fetchMovies();
    fetchBookings();
  }, []);

  const fetchMovies = () => fetch('/api/movies').then(res => res.json()).then(setMovies);
  const fetchBookings = () => fetch('/api/admin/bookings', {
    headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
  }).then(res => res.json()).then(setBookings);

  const handleSaveMovie = async (e: React.FormEvent) => {
    e.preventDefault();
    const method = editingMovie?.id ? 'PUT' : 'POST';
    const url = editingMovie?.id ? `/api/movies/${editingMovie.id}` : '/api/movies';

    try {
      const response = await fetch(url, {
        method,
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: JSON.stringify(editingMovie)
      });
      if (response.ok) {
        setIsModalOpen(false);
        setEditingMovie(null);
        fetchMovies();
      }
    } catch (error) {
      console.error('Save failed:', error);
    }
  };

  const deleteMovie = async (id: string) => {
    if (!confirm('Delete this movie?')) return;
    await fetch(`/api/movies/${id}`, {
      method: 'DELETE',
      headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
    });
    fetchMovies();
  };

  return (
    <div className="py-12 space-y-12">
      <div className="flex justify-between items-end">
        <div>
          <h1 className="text-4xl font-black text-white">Admin Dashboard</h1>
          <p className="text-slate-500 mt-2">Manage movies, bookings, and theater operations.</p>
        </div>
        <button 
          onClick={() => { setEditingMovie({ name: '', language: '', showTime: '', availableSeats: 40, image: '', description: '' }); setIsModalOpen(true); }}
          className="bg-indigo-600 hover:bg-indigo-500 text-white px-6 py-3 rounded-2xl font-bold flex items-center gap-2 transition-all"
        >
          <Plus className="w-5 h-5" />
          Add New Movie
        </button>
      </div>

      <div className="grid md:grid-cols-3 gap-8">
        <div className="bg-slate-900 p-8 rounded-3xl border border-slate-800 space-y-2">
          <Film className="w-8 h-8 text-indigo-500" />
          <p className="text-slate-500 text-sm uppercase font-bold">Total Movies</p>
          <p className="text-4xl font-black text-white">{movies.length}</p>
        </div>
        <div className="bg-slate-900 p-8 rounded-3xl border border-slate-800 space-y-2">
          <Ticket className="w-8 h-8 text-green-500" />
          <p className="text-slate-500 text-sm uppercase font-bold">Total Bookings</p>
          <p className="text-4xl font-black text-white">{bookings.length}</p>
        </div>
        <div className="bg-slate-900 p-8 rounded-3xl border border-slate-800 space-y-2">
          <Users className="w-8 h-8 text-purple-500" />
          <p className="text-slate-500 text-sm uppercase font-bold">Active Users</p>
          <p className="text-4xl font-black text-white">12</p>
        </div>
      </div>

      <div className="bg-slate-900 rounded-[2rem] border border-slate-800 overflow-hidden">
        <div className="p-8 border-b border-slate-800">
          <h3 className="text-xl font-bold text-white">Movie Management</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-slate-950 text-slate-500 text-xs uppercase font-bold">
              <tr>
                <th className="px-8 py-4">Movie</th>
                <th className="px-8 py-4">Language</th>
                <th className="px-8 py-4">Show Time</th>
                <th className="px-8 py-4">Seats</th>
                <th className="px-8 py-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {movies.map(movie => (
                <tr key={movie.id} className="hover:bg-slate-800/30 transition-colors">
                  <td className="px-8 py-4 font-bold text-white">{movie.name}</td>
                  <td className="px-8 py-4 text-slate-400">{movie.language}</td>
                  <td className="px-8 py-4 text-slate-400">{movie.showTime}</td>
                  <td className="px-8 py-4 text-slate-400">{movie.availableSeats}</td>
                  <td className="px-8 py-4 text-right space-x-2">
                    <button 
                      onClick={() => { setEditingMovie(movie); setIsModalOpen(true); }}
                      className="p-2 hover:bg-indigo-500/20 text-indigo-400 rounded-lg transition-colors"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button 
                      onClick={() => deleteMovie(movie.id)}
                      className="p-2 hover:bg-red-500/20 text-red-400 rounded-lg transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal */}
      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="absolute inset-0 bg-black/80 backdrop-blur-sm"
              onClick={() => setIsModalOpen(false)}
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative bg-slate-900 border border-slate-800 w-full max-w-2xl rounded-[2.5rem] shadow-2xl overflow-hidden"
            >
              <div className="p-8 border-b border-slate-800 flex justify-between items-center">
                <h2 className="text-2xl font-black text-white">{editingMovie?.id ? 'Edit Movie' : 'Add Movie'}</h2>
                <button onClick={() => setIsModalOpen(false)} className="p-2 hover:bg-slate-800 rounded-full text-slate-500"><X /></button>
              </div>
              <form onSubmit={handleSaveMovie} className="p-8 grid grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-500 uppercase">Movie Name</label>
                  <input required value={editingMovie?.name} onChange={e => setEditingMovie({...editingMovie, name: e.target.value})} className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-white focus:ring-2 focus:ring-indigo-500 outline-none" />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-500 uppercase">Language</label>
                  <input required value={editingMovie?.language} onChange={e => setEditingMovie({...editingMovie, language: e.target.value})} className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-white focus:ring-2 focus:ring-indigo-500 outline-none" />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-500 uppercase">Show Time</label>
                  <input required value={editingMovie?.showTime} onChange={e => setEditingMovie({...editingMovie, showTime: e.target.value})} className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-white focus:ring-2 focus:ring-indigo-500 outline-none" />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-500 uppercase">Available Seats</label>
                  <input type="number" required value={editingMovie?.availableSeats} onChange={e => setEditingMovie({...editingMovie, availableSeats: parseInt(e.target.value)})} className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-white focus:ring-2 focus:ring-indigo-500 outline-none" />
                </div>
                <div className="col-span-2 space-y-2">
                  <label className="text-xs font-bold text-slate-500 uppercase">Image URL</label>
                  <input required value={editingMovie?.image} onChange={e => setEditingMovie({...editingMovie, image: e.target.value})} className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-white focus:ring-2 focus:ring-indigo-500 outline-none" />
                </div>
                <div className="col-span-2 space-y-2">
                  <label className="text-xs font-bold text-slate-500 uppercase">Description</label>
                  <textarea rows={3} required value={editingMovie?.description} onChange={e => setEditingMovie({...editingMovie, description: e.target.value})} className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-white focus:ring-2 focus:ring-indigo-500 outline-none resize-none" />
                </div>
                <div className="col-span-2 pt-4">
                  <button type="submit" className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-black py-4 rounded-2xl transition-all">
                    Save Movie
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
