import { useState, useEffect } from 'react';
import { Booking } from '../types';
import { Ticket, XCircle, Calendar, Clock, MapPin } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function MyBookings() {
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchBookings();
  }, []);

  const fetchBookings = async () => {
    try {
      const response = await fetch('/api/bookings/my', {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
      });
      const data = await response.json();
      setBookings(data);
      setLoading(false);
    } catch (error) {
      console.error('Fetch failed:', error);
    }
  };

  const cancelBooking = async (id: string) => {
    if (!confirm('Are you sure you want to cancel this booking?')) return;

    try {
      const response = await fetch(`/api/bookings/${id}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
      });
      if (response.ok) {
        fetchBookings();
      }
    } catch (error) {
      console.error('Cancel failed:', error);
    }
  };

  if (loading) return <div className="flex justify-center py-20"><div className="animate-spin h-8 w-8 border-2 border-indigo-500 border-t-transparent rounded-full" /></div>;

  return (
    <div className="max-w-4xl mx-auto py-12 space-y-8">
      <div>
        <h1 className="text-4xl font-black text-white">My Bookings</h1>
        <p className="text-slate-500 mt-2">Manage your upcoming movie experiences.</p>
      </div>

      {bookings.length === 0 ? (
        <div className="bg-slate-900/50 border border-slate-800 rounded-[2rem] p-20 text-center space-y-4">
          <Ticket className="w-16 h-16 text-slate-700 mx-auto" />
          <p className="text-slate-500 text-lg">No bookings found. Start exploring movies!</p>
        </div>
      ) : (
        <div className="grid gap-6">
          <AnimatePresence>
            {bookings.map(booking => (
              <motion.div
                key={booking.id}
                layout
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="bg-slate-900 border border-slate-800 rounded-3xl p-6 flex flex-col md:flex-row items-center gap-8 group"
              >
                <div className="bg-indigo-600/20 p-4 rounded-2xl">
                  <Ticket className="w-8 h-8 text-indigo-500" />
                </div>
                
                <div className="flex-1 space-y-1 text-center md:text-left">
                  <h3 className="text-xl font-bold text-white">{booking.movieName}</h3>
                  <div className="flex flex-wrap justify-center md:justify-start gap-4 text-sm text-slate-500">
                    <span className="flex items-center gap-1.5"><Calendar className="w-4 h-4" /> Today</span>
                    <span className="flex items-center gap-1.5"><Clock className="w-4 h-4" /> {booking.showTime}</span>
                    <span className="flex items-center gap-1.5"><MapPin className="w-4 h-4" /> Screen 04</span>
                  </div>
                </div>

                <div className="text-center md:text-right">
                  <p className="text-xs uppercase text-slate-500 font-bold mb-1">Seats</p>
                  <p className="text-white font-bold">{booking.seats.join(', ')}</p>
                </div>

                <button 
                  onClick={() => cancelBooking(booking.id)}
                  className="bg-slate-800 hover:bg-red-500/10 hover:text-red-500 text-slate-400 p-3 rounded-2xl transition-all"
                  title="Cancel Booking"
                >
                  <XCircle className="w-6 h-6" />
                </button>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      )}
    </div>
  );
}
