import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Movie } from '../types';
import { ChevronLeft, Info, Clock, Globe, User, CheckCircle2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function MovieBooking() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [movie, setMovie] = useState<Movie | null>(null);
  const [selectedSeats, setSelectedSeats] = useState<number[]>([]);
  const [loading, setLoading] = useState(true);
  const [bookingStatus, setBookingStatus] = useState<'idle' | 'success'>('idle');

  const userStr = localStorage.getItem('user');
  const user = userStr ? JSON.parse(userStr) : null;

  useEffect(() => {
    fetch(`/api/movies/${id}`)
      .then(res => res.json())
      .then(data => {
        setMovie(data);
        setLoading(false);
      });
  }, [id]);

  const handleBooking = async () => {
    if (selectedSeats.length === 0) return;

    try {
      const response = await fetch('/api/bookings', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: JSON.stringify({
          movieId: movie?.id,
          seats: selectedSeats,
          userName: user?.name
        })
      });

      if (response.ok) {
        setBookingStatus('success');
      }
    } catch (error) {
      console.error('Booking failed:', error);
    }
  };

  const toggleSeat = (index: number) => {
    if (movie?.seats[index]) return;
    setSelectedSeats(prev => 
      prev.includes(index) ? prev.filter(i => i !== index) : [...prev, index]
    );
  };

  if (loading) return <div className="flex justify-center py-20"><div className="animate-spin h-8 w-8 border-2 border-indigo-500 border-t-transparent rounded-full" /></div>;
  if (!movie) return <div className="text-center py-20 text-white">Movie not found</div>;

  if (bookingStatus === 'success') {
    return (
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="max-w-md mx-auto text-center space-y-8 py-20"
      >
        <div className="w-24 h-24 bg-green-500/20 rounded-full flex items-center justify-center mx-auto">
          <CheckCircle2 className="w-12 h-12 text-green-500" />
        </div>
        <div className="space-y-2">
          <h2 className="text-4xl font-black text-white">Booking Confirmed!</h2>
          <p className="text-slate-400">Enjoy your movie at {movie.showTime}</p>
        </div>
        <button
          onClick={() => navigate('/my-bookings')}
          className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-4 rounded-2xl transition-all"
        >
          View My Bookings
        </button>
      </motion.div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto py-8 space-y-12">
      <button 
        onClick={() => navigate('/')}
        className="flex items-center gap-2 text-slate-400 hover:text-white transition-colors"
      >
        <ChevronLeft className="w-5 h-5" />
        Back to Movies
      </button>

      <div className="grid lg:grid-cols-2 gap-16">
        {/* Left: Movie Info */}
        <div className="space-y-8">
          <div className="relative aspect-video rounded-3xl overflow-hidden border border-slate-800 shadow-2xl">
            <img src={movie.image} alt={movie.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent" />
            <div className="absolute bottom-6 left-6">
              <h1 className="text-4xl font-black text-white">{movie.name}</h1>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="bg-slate-900/50 p-4 rounded-2xl border border-slate-800 flex items-center gap-3">
              <Globe className="w-5 h-5 text-indigo-400" />
              <div>
                <p className="text-[10px] uppercase text-slate-500 font-bold">Language</p>
                <p className="text-white font-bold">{movie.language}</p>
              </div>
            </div>
            <div className="bg-slate-900/50 p-4 rounded-2xl border border-slate-800 flex items-center gap-3">
              <Clock className="w-5 h-5 text-indigo-400" />
              <div>
                <p className="text-[10px] uppercase text-slate-500 font-bold">Show Time</p>
                <p className="text-white font-bold">{movie.showTime}</p>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="text-lg font-bold flex items-center gap-2 text-white">
              <Info className="w-5 h-5 text-indigo-400" />
              Synopsis
            </h3>
            <p className="text-slate-400 leading-relaxed">{movie.description}</p>
          </div>
        </div>

        {/* Right: Seat Selection */}
        <div className="bg-slate-900 p-8 rounded-[2rem] border border-slate-800 space-y-12">
          <div className="text-center">
            <div className="w-full h-1 bg-indigo-500/30 rounded-full mb-2" />
            <p className="text-[10px] uppercase tracking-[0.5em] text-slate-500">Screen</p>
          </div>

          <div className="grid grid-cols-8 gap-3 max-w-sm mx-auto">
            {movie.seats.map((isBooked, i) => (
              <button
                key={i}
                disabled={isBooked}
                onClick={() => toggleSeat(i)}
                className={`aspect-square rounded-lg transition-all ${
                  isBooked 
                    ? 'bg-slate-800 cursor-not-allowed opacity-50' 
                    : selectedSeats.includes(i)
                      ? 'bg-indigo-500 scale-110 shadow-lg shadow-indigo-500/40'
                      : 'bg-slate-700 hover:bg-slate-600'
                }`}
              />
            ))}
          </div>

          <div className="flex justify-center gap-6 text-xs text-slate-500">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-slate-700 rounded-sm" /> Available
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-indigo-500 rounded-sm" /> Selected
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-slate-800 rounded-sm" /> Booked
            </div>
          </div>

          <div className="pt-8 border-t border-slate-800 space-y-6">
            <div className="flex justify-between items-end">
              <div>
                <p className="text-slate-500 text-sm">Selected Seats</p>
                <p className="text-white font-bold text-lg">
                  {selectedSeats.length > 0 ? selectedSeats.join(', ') : 'None'}
                </p>
              </div>
              <div className="text-right">
                <p className="text-slate-500 text-sm">Total Price</p>
                <p className="text-3xl font-black text-white">${selectedSeats.length * 15}</p>
              </div>
            </div>

            <button
              disabled={selectedSeats.length === 0}
              onClick={handleBooking}
              className="w-full bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-800 disabled:text-slate-600 text-white font-black py-5 rounded-2xl transition-all text-xl"
            >
              Confirm Booking
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
