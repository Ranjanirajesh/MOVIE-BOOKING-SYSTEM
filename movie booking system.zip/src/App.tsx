import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import ProtectedRoute from './components/ProtectedRoute';
import MovieList from './pages/MovieList';
import MovieBooking from './pages/MovieBooking';
import MyBookings from './pages/MyBookings';
import AdminDashboard from './pages/AdminDashboard';
import Login from './pages/Login';
import Register from './pages/Register';

export default function App() {
  return (
    <Router>
      <div className="min-h-screen bg-slate-950 text-slate-100 font-sans selection:bg-indigo-500/30">
        <Navbar />
        <main className="max-w-7xl mx-auto px-4">
          <Routes>
            <Route path="/" element={<MovieList />} />
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route 
              path="/book/:id" 
              element={
                <ProtectedRoute>
                  <MovieBooking />
                </ProtectedRoute>
              } 
            />
            <Route 
              path="/my-bookings" 
              element={
                <ProtectedRoute>
                  <MyBookings />
                </ProtectedRoute>
              } 
            />
            <Route 
              path="/admin" 
              element={
                <ProtectedRoute adminOnly>
                  <AdminDashboard />
                </ProtectedRoute>
              } 
            />
          </Routes>
        </main>
        
        <footer className="border-t border-slate-900 py-12 mt-20">
          <div className="max-w-7xl mx-auto px-4 text-center text-slate-600 text-xs">
            © 2026 CineReserve. All rights reserved. Built for College Mini Project.
          </div>
        </footer>
      </div>
    </Router>
  );
}
