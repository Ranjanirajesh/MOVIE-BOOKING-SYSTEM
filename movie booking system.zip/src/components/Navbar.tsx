import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Film, User, LogOut, LayoutDashboard, Ticket } from 'lucide-react';

export default function Navbar() {
  const navigate = useNavigate();
  const userStr = localStorage.getItem('user');
  const user = userStr ? JSON.parse(userStr) : null;

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    navigate('/login');
  };

  return (
    <nav className="bg-slate-950 border-b border-slate-800 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2 group">
          <div className="bg-indigo-600 p-1.5 rounded-lg group-hover:scale-110 transition-transform">
            <Film className="w-6 h-6 text-white" />
          </div>
          <span className="text-xl font-bold tracking-tight bg-gradient-to-r from-white to-slate-400 bg-clip-text text-transparent">
            CineReserve
          </span>
        </Link>

        <div className="flex items-center gap-6">
          {user ? (
            <>
              <Link to="/my-bookings" className="text-slate-400 hover:text-white text-sm font-medium flex items-center gap-2">
                <Ticket className="w-4 h-4" />
                My Bookings
              </Link>
              {user.role === 'admin' && (
                <Link to="/admin" className="text-slate-400 hover:text-white text-sm font-medium flex items-center gap-2">
                  <LayoutDashboard className="w-4 h-4" />
                  Admin
                </Link>
              )}
              <div className="h-6 w-px bg-slate-800" />
              <div className="flex items-center gap-3">
                <div className="flex flex-col items-end">
                  <span className="text-sm font-bold text-white">{user.name}</span>
                  <span className="text-[10px] text-slate-500 uppercase tracking-wider">{user.role}</span>
                </div>
                <button 
                  onClick={handleLogout}
                  className="p-2 hover:bg-slate-900 rounded-full text-slate-400 hover:text-red-400 transition-colors"
                >
                  <LogOut className="w-5 h-5" />
                </button>
              </div>
            </>
          ) : (
            <div className="flex items-center gap-4">
              <Link to="/login" className="text-slate-400 hover:text-white text-sm font-medium">Login</Link>
              <Link to="/register" className="bg-indigo-600 hover:bg-indigo-500 text-white px-4 py-2 rounded-lg text-sm font-bold transition-colors">
                Register
              </Link>
            </div>
          )}
        </div>
      </div>
    </nav>
  );
}
